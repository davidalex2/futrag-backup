# Mosquitto-SpringBoot
## MQTT Pub/Sub with MQTT Mosquito and Spring Boot

###### This application is an example for integrating Eclipse Mosquitto with spring boot.

> Prerequisite :
Docker must be instaled to run docker compose, which will create an image of Mosquitto broker.
```
Docker-compose up
```
Run the Spring boot application and u will be able to see on the console the output 
